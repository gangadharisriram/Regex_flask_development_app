import re
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        testing_string = request.form.get('testing_string')
        regex_pattern = request.form.get('regex_pattern')
        return results(testing_string, regex_pattern)
    return render_template('index.html')

@app.route('/results', methods=['POST'])
def results(testing_string=None, regex_pattern=None):
    if testing_string is None:
        testing_string = request.form.get('testing_string')
    if regex_pattern is None:
        regex_pattern = request.form.get('regex_pattern')
    matches = find_matches(testing_string, regex_pattern)
    return render_template('results.html', testing_string=testing_string, regex_pattern=regex_pattern, matches=matches)

def find_matches(testing_string, regex_pattern):
    return re.findall(regex_pattern, testing_string)

@app.route("/validator",methods=["GET","POST"])
def validate():
    if request.method == "POST":
        mail = request.form.get("mail")
        if re.match(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", mail):
            result = f"Valid email address: {mail}"
        else:
            result = "Invalid email address"
        return render_template("email_validator.html", result=result)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)